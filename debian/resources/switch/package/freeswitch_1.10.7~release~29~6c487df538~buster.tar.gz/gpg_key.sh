#!/bin/sh

wget --http-user=signalwire --http-password=pat_7ZQ2sXW795zv9oXsdxsAYoTS -O /usr/share/keyrings/signalwire-freeswitch-repo.gpg https://freeswitch.signalwire.com/repo/deb/debian-release/signalwire-freeswitch-repo.gpg
